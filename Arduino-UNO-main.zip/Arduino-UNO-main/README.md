# Walking Stick for the Blind using Arduino UNO

The project includes object detection and light sensors along with talkie imports and speaker to make the user aware of objects in front of them.
